package com.mange.mobile.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class StockDTO {
    public long stockId;
    public int quantity;
    public long branchId;
    public String branchName;
    public long itemId;
    public String itemName;
    public String price;
}
