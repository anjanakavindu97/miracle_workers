package com.mange.mobile.repo;

import com.mange.mobile.entity.Branch;
import com.mange.mobile.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface StockRepo extends JpaRepository<Stock,Long> {
        @Query(value = "SELECT * FROM stock s WHERE s.branch_branch_id=?1", nativeQuery = true)
        List<Stock> getStockBranch(long branchId);
}
