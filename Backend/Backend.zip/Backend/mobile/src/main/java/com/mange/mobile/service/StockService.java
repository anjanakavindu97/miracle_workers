package com.mange.mobile.service;

import com.mange.mobile.dto.BranchDTO;
import com.mange.mobile.dto.StockDTO;

import java.util.List;

public interface StockService {
    public List<StockDTO> getStockBranch(long branchId);
}
