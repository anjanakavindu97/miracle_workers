package com.mange.mobile.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Branch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long branchId;
    public String branchName;
    public String location;
    public String address;
    public String contact;
    @OneToMany(mappedBy="branch")
    public List<Stock> stockList;

}
