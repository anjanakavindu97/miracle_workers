package com.mange.mobile.service.impl;

import com.mange.mobile.dto.StockDTO;
import com.mange.mobile.entity.Stock;
import com.mange.mobile.repo.StockRepo;
import com.mange.mobile.service.StockService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class StockServiceImpl implements StockService {
    public final StockRepo stockRepo;

    public StockServiceImpl(StockRepo stockRepo) {
        this.stockRepo = stockRepo;
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
    public List<StockDTO> getStockBranch(long branchId) {
        List<Stock> stockList = stockRepo.getStockBranch(branchId);
        List<StockDTO> stockDTOList=new ArrayList<>();
        for (Stock s:stockList) {
            StockDTO stockDTO=new StockDTO();
            if(s.getBranch()!=null){
                stockDTO.setBranchId(s.getBranch().getBranchId());
                stockDTO.setBranchName(s.getBranch().getBranchName());
            }
            if(s.getItem()!=null){
                stockDTO.setItemId(s.getItem().getItemId());
                stockDTO.setItemName(s.getItem().getName());
                stockDTO.setPrice(s.getItem().getPrice());
            }
            stockDTO.setStockId(s.getStockId());
            stockDTO.setQuantity(s.getQuantity());
            stockDTOList.add(stockDTO);
        }
        return stockDTOList;
    }
}
