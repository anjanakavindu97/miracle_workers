package com.mange.mobile.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public long stockId;
    public int quantity;
    @ManyToOne(fetch = FetchType.LAZY)
    public Branch branch;
    @ManyToOne(fetch = FetchType.LAZY)
    public Item item;

}
