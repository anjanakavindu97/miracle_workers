package com.mange.mobile.repo;

import com.mange.mobile.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BranchRepo extends JpaRepository<Branch,Long>{
//    @Query(value = "SELECT * ", nativeQuery = true)
//    List<Branch> getBranch(long branchId);
}
