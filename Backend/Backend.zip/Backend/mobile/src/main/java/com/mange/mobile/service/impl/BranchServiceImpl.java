package com.mange.mobile.service.impl;

import com.mange.mobile.dto.BranchDTO;
import com.mange.mobile.entity.Branch;
import com.mange.mobile.repo.BranchRepo;
import com.mange.mobile.service.BranchService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class BranchServiceImpl implements BranchService {
    public final BranchRepo branchRepo;

    public BranchServiceImpl(BranchRepo branchRepo) {
        this.branchRepo = branchRepo;
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
    public List<BranchDTO> getAllBranch() {
        List<Branch> branchList = branchRepo.findAll();
        List<BranchDTO> branchDTOList = new ArrayList<>();
        if (!branchList.isEmpty()) {
            for (Branch branch : branchList) {
                BranchDTO branchDTO = new BranchDTO();
                branchDTO.setAddress(branch.getAddress());
                branchDTO.setBranchId(branch.getBranchId());
                branchDTO.setContact(branch.getContact());
                branchDTO.setLocation(branch.getLocation());
                branchDTO.setBranchName(branch.getBranchName());
                branchDTOList.add(branchDTO);
            }

        }
        return branchDTOList;
    }
}
