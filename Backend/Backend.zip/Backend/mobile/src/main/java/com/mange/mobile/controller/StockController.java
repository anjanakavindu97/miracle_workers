package com.mange.mobile.controller;

import com.mange.mobile.dto.StockDTO;
import com.mange.mobile.service.StockService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("v1/stock")
public class StockController {
    public final StockService stockService;

    public StockController(StockService stockService) {
        this.stockService = stockService;
    }

    @GetMapping("/get/{branchId}")
    public List<StockDTO> getAllBranch(@PathVariable long branchId) {
        List<StockDTO> stockBranch = stockService.getStockBranch(branchId);
        return stockBranch;
    }
}
