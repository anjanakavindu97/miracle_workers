package com.mange.mobile.repo;

import com.mange.mobile.entity.Item;
import com.mange.mobile.entity.Stock;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemRepo extends JpaRepository<Item,Long> {

}
