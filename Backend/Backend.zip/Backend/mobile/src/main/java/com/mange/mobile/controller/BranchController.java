package com.mange.mobile.controller;

import com.mange.mobile.dto.BranchDTO;
import com.mange.mobile.service.BranchService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("v1/branch")
public class BranchController {
    public final BranchService branchService;

    public BranchController(BranchService branchService) {
        this.branchService = branchService;
    }
    @GetMapping("/get")
    public List<BranchDTO> getAllBranch() {
        List<BranchDTO> allBranch = branchService.getAllBranch();
        return allBranch;
    }
}
