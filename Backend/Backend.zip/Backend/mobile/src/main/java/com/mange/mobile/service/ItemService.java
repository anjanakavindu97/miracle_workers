package com.mange.mobile.service;

import com.mange.mobile.dto.BranchDTO;
import com.mange.mobile.dto.ItemSaveRequestDTO;

import java.util.List;

public interface ItemService {
    public void saveItem(ItemSaveRequestDTO dto);

    public void updateItem(ItemSaveRequestDTO dto);
}
