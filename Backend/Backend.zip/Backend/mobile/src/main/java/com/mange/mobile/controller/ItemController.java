package com.mange.mobile.controller;

import com.mange.mobile.dto.BranchDTO;
import com.mange.mobile.dto.ItemSaveRequestDTO;
import com.mange.mobile.service.ItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("v1/item")
public class ItemController {
    public final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @PostMapping("/save")
    public String saveItem(@RequestBody ItemSaveRequestDTO dto) {
        itemService.saveItem(dto);
        return "Save Successfully";
    }

    @PatchMapping("/update")
    public String getAllBranch(@RequestBody ItemSaveRequestDTO dto) {
        itemService.updateItem(dto);
        return "Update Successfully";
    }
}
