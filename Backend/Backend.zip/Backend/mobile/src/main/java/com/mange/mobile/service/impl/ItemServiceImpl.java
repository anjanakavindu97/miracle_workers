package com.mange.mobile.service.impl;

import com.mange.mobile.dto.ItemSaveRequestDTO;
import com.mange.mobile.entity.Item;
import com.mange.mobile.repo.ItemRepo;
import com.mange.mobile.service.ItemService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ItemServiceImpl implements ItemService {
    public final ItemRepo itemRepo;

    public ItemServiceImpl(ItemRepo itemRepo) {
        this.itemRepo = itemRepo;
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
    public void saveItem(ItemSaveRequestDTO dto) {
        Item item=new Item();
        item.setName(dto.getName());
        item.setPrice(dto.getPrice());
        item.setCategory(dto.getCategory());
        itemRepo.save(item);
    }

    @Override
    @Transactional(propagation = Propagation.SUPPORTS, rollbackFor = Exception.class)
    public void updateItem(ItemSaveRequestDTO dto) {
        Optional<Item> optionalItem = itemRepo.findById(dto.getItemId());
        if(optionalItem.isPresent()){
            Item item = optionalItem.get();
            item.setCategory(dto.getCategory());
            item.setPrice(dto.getPrice());
            item.setName(dto.getName());
            itemRepo.save(item);
        }
    }
}
