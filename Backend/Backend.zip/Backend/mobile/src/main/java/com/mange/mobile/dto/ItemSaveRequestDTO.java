package com.mange.mobile.dto;

import com.mange.mobile.entity.Stock;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.OneToMany;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ItemSaveRequestDTO {
    public long itemId;
    public String price;
    public String name;
    public String category;
}
